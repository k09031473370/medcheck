﻿<#
.SYNOPSIS
  健診ナビ11 検査結果一括取込ツール GUI版 (form_import_gui.ps1)

.DESCRIPTION
  form_import.ps1 (同じフォルダに必要) のGUIフロントエンド。
  - Excelフォーム(.xlsx)を直接指定可能 (ExcelのCOM機能で一時CSVに自動変換)
  - プレビュー / 書込 / 列確認(-Inspect) / 枠一覧(-DumpItems) / 所見マスタ(-DumpSyoken)
  起動方法: 右クリック→「PowerShellで実行」、または
    powershell -ExecutionPolicy Bypass -File C:\Users\User\Documents\excel_tools\form_import_gui.ps1
  ショートカットを作る場合のリンク先:
    powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File C:\Users\User\Documents\excel_tools\form_import_gui.ps1
#>
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$coreScript = Join-Path $scriptDir 'form_import.ps1'
if (-not (Test-Path $coreScript)) {
    [void][System.Windows.Forms.MessageBox]::Show("form_import.ps1 が見つかりません:`n$coreScript", 'エラー', 'OK', 'Error')
    return
}

# ============================================================================
# コア呼び出し
# ============================================================================

function Quote([string]$s) { return '"' + ($s -replace '"', '\"') + '"' }

# form_import.ps1 を別プロセスで実行し、出力テキストを返す
function Run-Core([string[]]$coreArgs) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $argStr = '-NoProfile -ExecutionPolicy Bypass -File ' + (Quote $coreScript)
    foreach ($a in $coreArgs) {
        if ($a -like '-*') { $argStr += ' ' + $a } else { $argStr += ' ' + (Quote $a) }
    }
    $psi.Arguments = $argStr
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.CreateNoWindow = $true
    $enc = [System.Text.Encoding]::GetEncoding(932)
    $psi.StandardOutputEncoding = $enc
    $psi.StandardErrorEncoding = $enc
    $p = [System.Diagnostics.Process]::Start($psi)
    $oT = $p.StandardOutput.ReadToEndAsync()
    $eT = $p.StandardError.ReadToEndAsync()
    $p.WaitForExit()
    $out = $oT.Result
    $err = $eT.Result
    if ((-not [string]::IsNullOrWhiteSpace($err))) { $out += "`r`n[エラー出力]`r`n" + $err }
    return $out
}


# ============================================================================
# GUI 構築
# ============================================================================

$form = New-Object System.Windows.Forms.Form
$form.Text = '健診ナビ 検査結果取込 (form_import GUI)'
$form.Size = New-Object System.Drawing.Size(960, 680)
$form.MinimumSize = New-Object System.Drawing.Size(760, 480)
$form.StartPosition = 'CenterScreen'

function New-Label([string]$text, [int]$x, [int]$y, [int]$w) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $text; $l.Location = New-Object System.Drawing.Point($x, $y)
    $l.Size = New-Object System.Drawing.Size($w, 20)
    return $l
}

# --- 1段目: ファイル選択 ---
$form.Controls.Add((New-Label 'フォーム (Excel/CSV):' 12 15 130))
$txtFile = New-Object System.Windows.Forms.TextBox
$txtFile.Location = New-Object System.Drawing.Point(145, 12)
$txtFile.Size = New-Object System.Drawing.Size(670, 24)
$txtFile.Anchor = 'Top,Left,Right'
$form.Controls.Add($txtFile)

$btnBrowse = New-Object System.Windows.Forms.Button
$btnBrowse.Text = '参照...'
$btnBrowse.Location = New-Object System.Drawing.Point(825, 10)
$btnBrowse.Size = New-Object System.Drawing.Size(105, 26)
$btnBrowse.Anchor = 'Top,Right'
$form.Controls.Add($btnBrowse)

# --- 2段目: 受付番号・受診日・オプション ---
$form.Controls.Add((New-Label '受付番号:' 12 48 70))
$txtOnly = New-Object System.Windows.Forms.TextBox
$txtOnly.Location = New-Object System.Drawing.Point(85, 45)
$txtOnly.Size = New-Object System.Drawing.Size(90, 24)
$tip = New-Object System.Windows.Forms.ToolTip
$tip.SetToolTip($txtOnly, "空欄=ファイル内の全員。複数指定はカンマ区切り (例: 4005,4009)")
$form.Controls.Add($txtOnly)

$form.Controls.Add((New-Label '受診日:' 195 48 55))
$txtYmd = New-Object System.Windows.Forms.TextBox
$txtYmd.Location = New-Object System.Drawing.Point(252, 45)
$txtYmd.Size = New-Object System.Drawing.Size(110, 24)
$form.Controls.Add($txtYmd)


$form.Controls.Add((New-Label 'レイアウト:' 380 48 70))
$cmbMap = New-Object System.Windows.Forms.ComboBox
$cmbMap.DropDownStyle = 'DropDownList'
$cmbMap.Location = New-Object System.Drawing.Point(448, 45)
$cmbMap.Size = New-Object System.Drawing.Size(210, 26)
[void]$cmbMap.Items.Add((New-Object PSObject -Property @{ Label = '自動判別 (おすすめ)'; File = 'auto' }))
foreach ($f in (Get-ChildItem (Join-Path $scriptDir 'form') -Filter 'mapping*.csv' -File -ErrorAction SilentlyContinue | Sort-Object Name)) {
    $label = $f.Name
    foreach ($ln in (Get-Content $f.FullName -TotalCount 5 -Encoding UTF8)) {
        if ($ln -match '^#\s*LABEL\s*=\s*(.+)$') { $label = $Matches[1].Trim(); break }
    }
    [void]$cmbMap.Items.Add((New-Object PSObject -Property @{ Label = $label; File = $f.Name }))
}
$cmbMap.DisplayMember = 'Label'
$cmbMap.ValueMember = 'File'
if ($cmbMap.Items.Count -gt 0) { $cmbMap.SelectedIndex = 0 }
$form.Controls.Add($cmbMap)

$chkNoHdr = New-Object System.Windows.Forms.CheckBox
$chkNoHdr.Text = '見出し行なし(手動)'
$chkNoHdr.Checked = $false
$chkNoHdr.Location = New-Object System.Drawing.Point(668, 45)
$chkNoHdr.Size = New-Object System.Drawing.Size(140, 24)
$form.Controls.Add($chkNoHdr)

$chkUtf8 = New-Object System.Windows.Forms.CheckBox
$chkUtf8.Text = 'CSVはUTF-8'
$chkUtf8.Location = New-Object System.Drawing.Point(812, 45)
$chkUtf8.Size = New-Object System.Drawing.Size(110, 24)
$form.Controls.Add($chkUtf8)

$chkForce = New-Object System.Windows.Forms.CheckBox
$chkForce.Text = 'エラーを飛ばす'
$chkForce.Location = New-Object System.Drawing.Point(834, 72)
$chkForce.Size = New-Object System.Drawing.Size(110, 24)
$chkForce.Anchor = 'Top,Right'
$form.Controls.Add($chkForce)

# --- 3段目: ボタン ---
$btnInspect = New-Object System.Windows.Forms.Button
$btnInspect.Text = '1. 列確認'
$btnInspect.Location = New-Object System.Drawing.Point(12, 80)
$btnInspect.Size = New-Object System.Drawing.Size(110, 32)
$form.Controls.Add($btnInspect)

$btnDump = New-Object System.Windows.Forms.Button
$btnDump.Text = '2. 枠一覧(DB)'
$btnDump.Location = New-Object System.Drawing.Point(128, 80)
$btnDump.Size = New-Object System.Drawing.Size(110, 32)
$form.Controls.Add($btnDump)

$btnUkeNo = New-Object System.Windows.Forms.Button
$btnUkeNo.Text = '受付番号を設定'
$btnUkeNo.Location = New-Object System.Drawing.Point(12, 118)
$btnUkeNo.Size = New-Object System.Drawing.Size(226, 30)
$form.Controls.Add($btnUkeNo)

$btnYoyaku = New-Object System.Windows.Forms.Button
$btnYoyaku.Text = '予約取込ファイルを作成'
$btnYoyaku.Location = New-Object System.Drawing.Point(244, 118)
$btnYoyaku.Size = New-Object System.Drawing.Size(180, 30)
$form.Controls.Add($btnYoyaku)

$form.Controls.Add((New-Label '← 受付番号の設定 / 予約取込用のExcelを作成' 430 124 320))

$btnPreview = New-Object System.Windows.Forms.Button
$btnPreview.Text = '3. プレビュー'
$btnPreview.Location = New-Object System.Drawing.Point(244, 80)
$btnPreview.Size = New-Object System.Drawing.Size(120, 32)
$btnPreview.Font = New-Object System.Drawing.Font($btnPreview.Font, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($btnPreview)

$btnCommit = New-Object System.Windows.Forms.Button
$btnCommit.Text = '4. 書込実行'
$btnCommit.Location = New-Object System.Drawing.Point(370, 80)
$btnCommit.Size = New-Object System.Drawing.Size(120, 32)
$btnCommit.ForeColor = [System.Drawing.Color]::Firebrick
$btnCommit.Font = New-Object System.Drawing.Font($btnCommit.Font, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($btnCommit)

$form.Controls.Add((New-Label '所見マスタ:' 530 87 75))
$cmbSyoken = New-Object System.Windows.Forms.ComboBox
$cmbSyoken.DropDownStyle = 'DropDownList'
[void]$cmbSyoken.Items.AddRange(@('SHIN (診察)','GANTEI (眼底)','ZK011 (心電図)','ZK020 (胸部X線 部位)','ZK021 (胸部X線 所見)','ZK030 (胃部X線 部位)','ZK031 (胃部X線 所見)','ZK041 (腹部エコー)'))
$cmbSyoken.SelectedIndex = 0
$cmbSyoken.Location = New-Object System.Drawing.Point(605, 84)
$cmbSyoken.Size = New-Object System.Drawing.Size(190, 26)
$form.Controls.Add($cmbSyoken)

$btnSyoken = New-Object System.Windows.Forms.Button
$btnSyoken.Text = '表示'
$btnSyoken.Location = New-Object System.Drawing.Point(800, 80)
$btnSyoken.Size = New-Object System.Drawing.Size(60, 32)
$form.Controls.Add($btnSyoken)

# --- 4段目: 名簿でしぼり込む (血液など、名簿外の人が混ざるファイル用) ---
$form.Controls.Add((New-Label '名簿でしぼり込む:' 12 156 115))
$txtRoster = New-Object System.Windows.Forms.TextBox
$txtRoster.Location = New-Object System.Drawing.Point(130, 153)
$txtRoster.Size = New-Object System.Drawing.Size(575, 24)
$txtRoster.Anchor = 'Top,Left,Right'
$tip.SetToolTip($txtRoster, "空欄=ファイル内の全員を取込。名簿(リアン等)を指定すると、その名簿に載っている人だけを取り込みます。")
$form.Controls.Add($txtRoster)

$btnRoster = New-Object System.Windows.Forms.Button
$btnRoster.Text = '名簿を選ぶ'
$btnRoster.Location = New-Object System.Drawing.Point(712, 151)
$btnRoster.Size = New-Object System.Drawing.Size(100, 26)
$btnRoster.Anchor = 'Top,Right'
$form.Controls.Add($btnRoster)

$btnRosterClear = New-Object System.Windows.Forms.Button
$btnRosterClear.Text = 'クリア'
$btnRosterClear.Location = New-Object System.Drawing.Point(818, 151)
$btnRosterClear.Size = New-Object System.Drawing.Size(70, 26)
$btnRosterClear.Anchor = 'Top,Right'
$form.Controls.Add($btnRosterClear)

$form.Controls.Add((New-Label 'パスワード:' 300 184 80))
$txtPw = New-Object System.Windows.Forms.TextBox
$txtPw.Location = New-Object System.Drawing.Point(378, 181)
$txtPw.Size = New-Object System.Drawing.Size(130, 24)
$txtPw.UseSystemPasswordChar = $true
$tip.SetToolTip($txtPw, "パスワード付きExcel(SRLの血液など)のときだけ入力します。例: srl")
$form.Controls.Add($txtPw)

$chkIgnoreName = New-Object System.Windows.Forms.CheckBox
$chkIgnoreName.Text = '氏名の違いを無視する (テストデータ用)'
$chkIgnoreName.Location = New-Object System.Drawing.Point(12, 184)
$chkIgnoreName.Size = New-Object System.Drawing.Size(270, 24)
$tip.SetToolTip($chkIgnoreName, "通常はチェックしません。Excelの氏名と健診ナビの氏名が違う人は、別人への書込を防ぐためスキップします。")
$form.Controls.Add($chkIgnoreName)

# --- 出力欄 ---
$txtOut = New-Object System.Windows.Forms.TextBox
$txtOut.Multiline = $true
$txtOut.ReadOnly = $true
$txtOut.ScrollBars = 'Both'
$txtOut.WordWrap = $false
$txtOut.Font = New-Object System.Drawing.Font('MS Gothic', 9)
$txtOut.Location = New-Object System.Drawing.Point(12, 214)
$txtOut.Size = New-Object System.Drawing.Size(918, 413)
$txtOut.Anchor = 'Top,Bottom,Left,Right'
$form.Controls.Add($txtOut)

# ============================================================================
# イベント
# ============================================================================

# どのボタンの結果かひと目で分かるように見出しを出す
function Start-Section([string]$title) {
    $bar = '─' * 60
    $txtOut.AppendText($bar + "`r`n")
    $txtOut.AppendText(('■ ' + $title + '   ' + (Get-Date -Format 'HH:mm:ss')) + "`r`n")
    $txtOut.AppendText($bar + "`r`n")
    $txtOut.SelectionStart = $txtOut.Text.Length
    $txtOut.ScrollToCaret()
    [System.Windows.Forms.Application]::DoEvents()
}

function Append-Out([string]$text) {
    $txtOut.AppendText($text.TrimEnd() + "`r`n`r`n")
    $txtOut.SelectionStart = $txtOut.Text.Length
    $txtOut.ScrollToCaret()
}

$allButtons = @($btnBrowse, $btnInspect, $btnDump, $btnPreview, $btnCommit, $btnSyoken, $btnUkeNo, $btnYoyaku, $btnRoster, $btnRosterClear)

function Invoke-Busy([scriptblock]$work) {
    foreach ($b in $allButtons) { $b.Enabled = $false }
    $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
    [System.Windows.Forms.Application]::DoEvents()
    try { & $work }
    catch { Append-Out ("[エラー] " + $_.Exception.Message) }
    finally {
        foreach ($b in $allButtons) { $b.Enabled = $true }
        $form.Cursor = [System.Windows.Forms.Cursors]::Default
    }
}

# 入力ファイルを解決 (.xlsx/.xlsm なら一時CSVに変換)
function Resolve-CsvPath {
    $f = $txtFile.Text.Trim().Trim('"')
    if ($f -eq '') { throw 'フォームのファイルを選択してください。' }
    if (-not (Test-Path $f)) { throw "ファイルが見つかりません: $f" }
    $ext = [System.IO.Path]::GetExtension($f).ToLower()
    if ($ext -eq '.xls') {
        throw "古い形式(.xls)は読めません。Excelで開いて .xlsx として保存し直してください。`n$f"
    }
    # .xlsx / .xlsm は form_import.ps1 が直接読む (Excelを使わないので固まらない)
    return $f
}

# プレビューと書込が「同じ条件」かを機械的に確かめるための指紋。
#   取込内容を左右するものは全部入れる:
#     入力ファイル・名簿 (中身が差し替わっても分かるよう更新日時とサイズも)
#     画面の入力とチェック
#     form\ の対応表すべて (自動判別のときレイアウト名は 'auto' 固定で、
#       mapping や code_map を書き換えても名前だけでは分からないため)
#     取込エンジン本体 (更新の直後に古いプレビューで書込むのを防ぐ)
$script:PreviewSig = $null
function Get-FileStamp([string]$p) {
    if ($p -eq '' -or -not (Test-Path $p)) { return $p }
    $fi = Get-Item $p
    return ('{0}|{1:yyyyMMddHHmmss}|{2}' -f $fi.FullName, $fi.LastWriteTimeUtc, $fi.Length)
}
function Get-ConditionSig {
    $parts = @()
    foreach ($t in @($txtFile, $txtRoster)) { $parts += Get-FileStamp ($t.Text.Trim().Trim('"')) }
    $parts += $txtOnly.Text.Trim()
    $parts += $txtYmd.Text.Trim()
    $parts += $(if ($cmbMap.SelectedItem) { [string]$cmbMap.SelectedItem.File } else { '' })
    $parts += [string]$chkNoHdr.Checked
    $parts += [string]$chkUtf8.Checked
    $parts += [string]$chkForce.Checked
    $parts += [string]$chkIgnoreName.Checked
    # 対応表フォルダの中身すべて
    foreach ($f in (Get-ChildItem (Join-Path $scriptDir 'form') -File -ErrorAction SilentlyContinue | Sort-Object Name)) {
        $parts += Get-FileStamp $f.FullName
    }
    # スクリプト本体
    foreach ($n in @('form_import.ps1', 'xlsx_read.ps1')) {
        $parts += Get-FileStamp (Join-Path $scriptDir $n)
    }
    return ($parts -join "`n")
}

# 共通引数 (受付番号・受診日・エンコーディング)
function Get-CommonArgs {
    $a = @()
    if ($txtOnly.Text.Trim() -ne '') { $a += @('-Only', $txtOnly.Text.Trim()) }
    if ($txtYmd.Text.Trim()  -ne '') { $a += @('-KenYmd', $txtYmd.Text.Trim()) }
    if ($chkUtf8.Checked) { $a += @('-CsvEncoding', 'UTF8') }
    if ($chkNoHdr.Checked) { $a += '-NoHeader' }
    if ($cmbMap.SelectedItem) { $a += @('-Mapping', [string]$cmbMap.SelectedItem.File) }
    if ($txtRoster.Text.Trim() -ne '') { $a += @('-Roster', $txtRoster.Text.Trim().Trim('"')) }
    if ($chkIgnoreName.Checked) { $a += '-IgnoreName' }
    if ($txtPw.Text -ne '') { $a += @('-Password', $txtPw.Text) }
    return ,$a
}

$btnBrowse.Add_Click({
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Filter = 'Excel/CSV|*.xlsx;*.xlsm;*.xls;*.csv|すべて|*.*'
    if ($dlg.ShowDialog() -eq 'OK') { $txtFile.Text = $dlg.FileName }
})

$btnRoster.Add_Click({
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Filter = 'Excel/CSV|*.xlsx;*.xlsm;*.xls;*.csv|すべて|*.*'
    $dlg.Title = '名簿ファイル(リアン等)を選んでください'
    if ($dlg.ShowDialog() -eq 'OK') { $txtRoster.Text = $dlg.FileName }
})

$btnRosterClear.Add_Click({ $txtRoster.Text = '' })

$btnInspect.Add_Click({
    Invoke-Busy {
        Start-Section '1. 列確認 (ファイルを見るだけ・DBは触りません)'
        $csv = Resolve-CsvPath
        Append-Out (Run-Core (@('-Csv', $csv, '-Inspect') + (Get-CommonArgs)))
    }
})

$btnDump.Add_Click({
    Invoke-Busy {
        Start-Section '2. 枠一覧(DB) (健診ナビを読むだけ・書き込みません)'
        # ファイルが選ばれていれば、受付番号・受診日が空欄でもファイルから拾う
        $a = @('-DumpItems')
        $f = $txtFile.Text.Trim().Trim('"')
        if ($f -ne '' -and (Test-Path $f)) {
            $a += @('-Csv', (Resolve-CsvPath))
            if ($chkUtf8.Checked)  { $a += @('-CsvEncoding', 'UTF8') }
            if ($chkNoHdr.Checked) { $a += '-NoHeader' }
            if ($cmbMap.SelectedItem) { $a += @('-Mapping', [string]$cmbMap.SelectedItem.File) }
            if ($txtPw.Text -ne '') { $a += @('-Password', $txtPw.Text) }
        }
        elseif ($txtOnly.Text.Trim() -eq '' -or $txtYmd.Text.Trim() -eq '') {
            throw 'ファイルを選ぶか、受付番号と受診日の両方を入力してください。'
        }
        if ($txtOnly.Text.Trim() -ne '') { $a += @('-Only', $txtOnly.Text.Trim()) }
        if ($txtYmd.Text.Trim()  -ne '') { $a += @('-KenYmd', $txtYmd.Text.Trim()) }
        Append-Out (Run-Core $a)
    }
})

# 受診日欄に入力があり、かつファイルにも日付の列がある場合は、
# どちらを使うのかを必ず確認する (ファイルの日付を黙って無視しないため)
function Confirm-YmdOverride([string]$csv) {
    $typed = $txtYmd.Text.Trim()
    if ($typed -eq '') { return $true }

    $a = @('-Csv', $csv, '-ShowYmd', '-KenYmd', $typed)
    if ($chkUtf8.Checked)  { $a += @('-CsvEncoding', 'UTF8') }
    if ($chkNoHdr.Checked) { $a += '-NoHeader' }
    if ($cmbMap.SelectedItem) { $a += @('-Mapping', [string]$cmbMap.SelectedItem.File) }
    if ($txtPw.Text -ne '') { $a += @('-Password', $txtPw.Text) }
    $out = Run-Core $a

    $fileYmd = ''; $inYmd = ''
    foreach ($ln in ($out -split "`r?`n")) {
        if ($ln -match '^FILEYMD=(.*)$')  { $fileYmd = $Matches[1].Trim() }
        if ($ln -match '^INPUTYMD=(.*)$') { $inYmd   = $Matches[1].Trim() }
    }

    if ($inYmd -eq '') {
        [void][System.Windows.Forms.MessageBox]::Show(
            "受診日「$typed」を解釈できません。`r`n2026/07/12 のように入力してください。",
            '受診日の書き方', 'OK', 'Error')
        return $false
    }
    # 日付の列が無いファイル(芝浦巡回AIデータ等)は、受診日欄が唯一の情報源なので確認不要
    if ($fileYmd -eq '') { return $true }
    if ($fileYmd -eq $inYmd) { return $true }

    $msg = "このファイルには受診日の列があります。`r`n`r`n" +
           "  ファイルの日付 : $fileYmd`r`n" +
           "  入力した受診日 : $inYmd`r`n`r`n" +
           "入力した $inYmd を使い、ファイルの日付は無視します。`r`n" +
           "よろしいですか?`r`n`r`n" +
           "（ファイルの日付 $fileYmd を使いたい場合は「いいえ」を押し、受診日欄を空欄にしてください）"
    $r = [System.Windows.Forms.MessageBox]::Show($msg, '受診日の確認', 'YesNo', 'Warning', 'Button2')
    if ($r -ne 'Yes') {
        Append-Out "[中止] 受診日の確認でキャンセルしました。受診日欄を空欄にすると、ファイルの日付 $fileYmd を使います。"
        return $false
    }
    Append-Out "[受診日] 入力された $inYmd を使います (ファイルの日付 $fileYmd は使いません)。"
    return $true
}

$btnPreview.Add_Click({
    Invoke-Busy {
        Start-Section '3. プレビュー (書き込みません)'
        $csv = Resolve-CsvPath
        if (-not (Confirm-YmdOverride $csv)) { return }
        Append-Out (Run-Core (@('-Csv', $csv) + (Get-CommonArgs)))
        $script:PreviewSig = Get-ConditionSig
    }
})

$btnCommit.Add_Click({
    Invoke-Busy {
        Start-Section '4. 書込実行 (健診ナビに書き込みます)'
        $csv = Resolve-CsvPath
        if (-not (Confirm-YmdOverride $csv)) { return }

        # プレビューと同じ条件か
        $sigNow = Get-ConditionSig
        if ($null -eq $script:PreviewSig) {
            $r0 = [System.Windows.Forms.MessageBox]::Show(
                "まだプレビューをしていません。`r`nプレビューを見ずに書込むと、内容を確認できません。`r`n`r`nこのまま続けますか?",
                'プレビュー未実施', 'YesNo', 'Warning', 'Button2')
            if ($r0 -ne 'Yes') { Append-Out '[中止] 先に「3. プレビュー」を押してください。'; return }
        }
        elseif ($sigNow -ne $script:PreviewSig) {
            $before = $script:PreviewSig -split "`n"
            $after  = $sigNow -split "`n"
            $names = @('取込ファイル','名簿','受付番号','受診日','レイアウト','見出し行なし','CSVはUTF-8','エラーを飛ばす','氏名の違いを無視')
            $changed = @()
            for ($i = 0; $i -lt [Math]::Max($before.Count, $after.Count); $i++) {
                $b = if ($i -lt $before.Count) { $before[$i] } else { '' }
                $a = if ($i -lt $after.Count)  { $after[$i]  } else { '' }
                if ($b -ne $a) {
                    if ($i -lt $names.Count) { $changed += $names[$i] }
                    elseif ($changed -notcontains '対応表またはツール本体') { $changed += '対応表またはツール本体' }
                }
            }
            $what = if ($changed.Count -gt 0) { '変わったもの: ' + ($changed -join ' / ') } else { 'ファイルの中身が変わっています' }
            $r0 = [System.Windows.Forms.MessageBox]::Show(
                "プレビューしたときと条件が変わっています。`r`n$what`r`n`r`n" +
                "このまま書込むと、確認した内容と違うものが書き込まれます。`r`nもう一度プレビューし直すことを強くおすすめします。`r`n`r`nそれでも続けますか?",
                'プレビューと条件が違います', 'YesNo', 'Warning', 'Button2')
            if ($r0 -ne 'Yes') { Append-Out '[中止] 条件が変わっています。もう一度「3. プレビュー」を押してください。'; return }
        }

        # 非常口を使うときは、何を無視するのかを明示して確認する
        $bypass = @()
        if ($chkForce.Checked)      { $bypass += 'エラーのある項目を飛ばして書込む' }
        if ($chkIgnoreName.Checked) { $bypass += '氏名が違う人にも書込む(別人に書く恐れ)' }
        if ($bypass.Count -gt 0) {
            $r0 = [System.Windows.Forms.MessageBox]::Show(
                ("通常の安全確認を外した状態です。`r`n`r`n・" + ($bypass -join "`r`n・") + "`r`n`r`n本当にこの設定で書込みますか?"),
                '安全確認を外しています', 'YesNo', 'Warning', 'Button2')
            if ($r0 -ne 'Yes') { Append-Out '[中止] 安全確認の外しをキャンセルしました。'; return }
        }

        $who = if ($txtOnly.Text.Trim() -ne '') { '受付番号 ' + $txtOnly.Text.Trim() + ' の1名' } else { 'CSVの全員' }
        $msg = "$who にDB書込を実行します。`r`n先にプレビューで内容を確認しましたか?"
        $r = [System.Windows.Forms.MessageBox]::Show($msg, '書込の確認', 'YesNo', 'Warning', 'Button2')
        if ($r -ne 'Yes') { Append-Out '[中止] 書込をキャンセルしました。'; return }
        $a = @('-Csv', $csv, '-Commit') + (Get-CommonArgs)
        if ($chkForce.Checked) { $a += '-Force' }
        Append-Out (Run-Core $a)
        # 付けっぱなしで次の人に使われないよう、書込のたびに戻す
        if ($chkForce.Checked -or $chkIgnoreName.Checked) {
            $chkForce.Checked = $false
            $chkIgnoreName.Checked = $false
            Append-Out '[安全確認] 「エラーを飛ばす」「氏名の違いを無視する」のチェックを外しました。'
        }
        $script:PreviewSig = $null
    }
})

$btnUkeNo.Add_Click({
    Invoke-Busy {
        Start-Section '受付番号を設定'
        $csv = Resolve-CsvPath
        if (-not (Confirm-YmdOverride $csv)) { return }
        $a = @('-Csv', $csv, '-SetUkeNo') + (Get-CommonArgs)
        Append-Out (Run-Core $a)
        $r = [System.Windows.Forms.MessageBox]::Show(
            "上のプレビューを確認しました。`r`n「OK」の人の受付番号を健診ナビへ設定しますか?",
            '受付番号の設定', 'YesNo', 'Warning', 'Button2')
        if ($r -ne 'Yes') { Append-Out '[中止] 受付番号の設定をキャンセルしました。'; return }
        Append-Out (Run-Core ($a + '-Commit'))
    }
})

$btnYoyaku.Add_Click({
    Invoke-Busy {
        Start-Section '予約取込ファイルを作成'
        $f = $txtFile.Text.Trim().Trim('"')
        if ($f -eq '') { throw 'フォームのファイルを選択してください。' }
        $yo = Join-Path $scriptDir 'yoyaku_export.ps1'
        if (-not (Test-Path $yo)) { throw "yoyaku_export.ps1 が見つかりません: $yo" }
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
        $arg = '-NoProfile -ExecutionPolicy Bypass -File ' + (Quote $yo) + ' -Csv ' + (Quote $f)
        if ($chkNoHdr.Checked) { $arg += ' -NoHeader' }
        $psi.Arguments = $arg
        $psi.UseShellExecute = $false
        $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true; $psi.CreateNoWindow = $true
        $enc = [System.Text.Encoding]::GetEncoding(932)
        $psi.StandardOutputEncoding = $enc; $psi.StandardErrorEncoding = $enc
        $p = [System.Diagnostics.Process]::Start($psi)
        $oT = $p.StandardOutput.ReadToEndAsync(); $eT = $p.StandardError.ReadToEndAsync()
        $p.WaitForExit()
        $o = $oT.Result
        if (-not [string]::IsNullOrWhiteSpace($eT.Result)) { $o += "`r`n[エラー出力]`r`n" + $eT.Result }
        Append-Out $o
    }
})

$btnSyoken.Add_Click({
    Invoke-Busy {
        Start-Section '所見マスタ表示'
        $cd = ($cmbSyoken.SelectedItem -split ' ')[0]
        Append-Out (Run-Core @('-DumpSyoken', $cd))
    }
})

Append-Out @'
使い方:
 1. 「参照...」でフォーム(.xlsx または .csv)を選択
 2. 受付番号(例 4001)と受診日(例 2026/07/02)を入力
 3. 「1.列確認」で列の並びを確認 → form\mapping.csv を整備 (初回のみ)
 4. 「2.枠一覧(DB)」で KOMOKU_CD を確認 → mapping.csv に記入 (初回のみ)
 5. 「3.プレビュー」で書込内容を確認
 6. 問題なければ「4.書込実行」 → 健診ナビで「自動判定」を実行
'@

[void]$form.ShowDialog()
